#!/usr/bin/env python
# coding: utf-8

# In[2]:


import numpy as np
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, confusion_matrix, classification_report

df=pd.read_csv("TitanicFinal.csv",sep=';')


# In[3]:


df.head()


# In[4]:


df=df.drop("Ticket",axis=1)


# In[5]:


df=df.drop("Cabin",axis=1)


# In[6]:


df=df.drop("Name",axis=1)


# In[7]:


df=df.drop("PassengerId",axis=1)


# In[8]:


df.head()


# In[9]:


df.describe()


# In[10]:


df['Sex'] = df['Sex'].replace({'male': 1, 'female': 2})


# In[11]:


df.head()


# In[12]:


df['Embarked'] = df['Embarked'].replace({'S': 0, 'C': 1, 'Q': 2})


# In[13]:


df['Age'] = df['Age'].fillna(df['Age'].median())


# In[14]:


df.dropna(subset=['Parch'], inplace=True)


# In[15]:


df.dropna(subset=['Fare'], inplace=True)


# In[16]:


df.dropna(subset=['Embarked'], inplace=True)


# In[17]:


nan_count_per_column = df.isna().sum()
print(nan_count_per_column)


# In[18]:


X = df.drop('Survived',axis=1)
y=df['Survived']


# In[19]:


X.head()


# In[20]:


y.head()


# In[21]:


df.tail(10)


# In[22]:


X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.25, random_state=32)


# In[23]:


model = LogisticRegression()
model.fit(X_train, y_train)


# In[24]:


y_pred = model.predict(X_test)


# In[25]:


print("Accuracy:", accuracy_score(y_test, y_pred))


# In[26]:


print("Classification Report:\n", classification_report(y_test, y_pred))


# In[27]:


conf_mat=confusion_matrix(y_test, y_pred)
plt.figure(figsize=(8,6))
sns.heatmap(conf_mat,annot=True,fmt='d',cmap='Blues',xticklabels=model.classes_,yticklabels=model.classes_)
plt.xlabel("Prediction")
plt.ylabel("True Values")
plt.title("Confusion Matrix")
plt.show()


# In[28]:


def did_he_survive():
    print("Enter the following informations about a passenger to know if he would have survived")
    Pclass=int(input("Enter the Pclass"))
    Sex=int(input("Enter 1 if he is a male, 2 if she is a female"))
    Age=int(input("Enter the Age"))
    SibSp=int(input("Enter the number of Siblings"))
    Parch=int(input("Enter 0 if he is a parent or 1 if he is a child"))
    Fare=float(input("Enter the fare"))
    Embarked=int(input("Enter 0 if S, 1 if C, 2 if Q"))
                       
    passenger=pd.DataFrame({
        'Pclass': [Pclass],
        'Sex': [Sex],
        'Age': [Age],
        'SibSp': [SibSp],
        'Parch': [Parch],
        'Fare': [Fare],
        'Embarked': [Embarked]
    })
                       
    survie_predite = model.predict(passenger)
                       
    if survie_predite==1:
        print("Le passager a survecu")
    else : print("Le passager n'a pas Survecu")


# In[29]:


did_he_survive()


# In[ ]:


did_he_survive()


# In[30]:


coefficients = model.coef_[0]
feature_names = X.columns


# In[31]:


coef_df = pd.DataFrame({'Feature': feature_names, 'Coefficient': coefficients})


# In[32]:


coef_df['Abs_Coefficient'] = np.abs(coef_df['Coefficient'])
coef_df = coef_df.sort_values(by='Abs_Coefficient', ascending=False)


# In[33]:


plt.figure(figsize=(10, 6))
sns.barplot(x='Coefficient', y='Feature', data=coef_df, palette='viridis')
plt.title('Feature Importance - Logistic Regression')
plt.show()


# In[ ]:




