#!/usr/bin/env python
# coding: utf-8

# In[113]:


import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score
from sklearn.model_selection import GridSearchCV

df=pd.read_csv("IRIS_ Flower_Dataset.csv")
df.head()


# In[114]:


df.describe()


# In[115]:


X = df.drop('species',axis=1)
y=df['species']


# In[116]:


X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.25, random_state=32)


# In[223]:


df_model.fit(X_train, y_train)
y_pred = df_model.predict(X_test)


# In[224]:


accuracy = accuracy_score(y_test, y_pred)


# In[225]:


print(f"Accuracy: {accuracy}")


# In[226]:


param_grid = {
    'n_estimators': [50, 100, 150],
    'max_depth': [None, 10, 20, 30],
    'min_samples_split': [2, 5, 10],
    'min_samples_leaf': [1, 2, 4]
}


# In[157]:


grid_search = GridSearchCV(estimator=df_model, param_grid=param_grid, cv=2)


# In[158]:


grid_search.fit(X_train, y_train)


# In[251]:


print("Grid Search Results:")
print(pd.DataFrame(grid_search.cv_results_))


# In[252]:


best_params = grid_search.best_params_
print(f"Best Hyperparameters: {best_params}")


# In[262]:


new_model=RandomForestClassifier(max_depth= 10, min_samples_leaf=4, min_samples_split=2, n_estimators=100)


# In[263]:


new_model.fit(X_train,y_train)


# In[264]:


newy_pred=new_model.predict(X_test)


# In[265]:


new_accuracy=accuracy_score(y_test, newy_pred)
print(f"Accuracy with Best Hyperparameters: {accuracy}")


# In[231]:


#Same accuracy ?


# In[232]:


import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.metrics import confusion_matrix


# In[149]:


cm = confusion_matrix(y_test, y_pred)
plt.figure(figsize=(8, 6))
sns.heatmap(cm, annot=True, fmt='d', cmap='Blues', cbar=False)
plt.xlabel('Predicted Labels')
plt.ylabel('True Labels')
plt.title('Confusion Matrix')
plt.show()


# In[151]:


feature_importance = new_model.feature_importances_
feature_names = X.columns
df_feature_importance = pd.DataFrame({'Feature': feature_names, 'Importance': feature_importance})
df_feature_importance = df_feature_importance.sort_values(by='Importance', ascending=False)

plt.figure(figsize=(10, 6))
sns.barplot(x='Importance', y='Feature', data=df_feature_importance, palette='viridis')
plt.title('Feature Importance')
plt.show()
#Feature importance shows the importance of each feature, the more importance a feature has the more it contributed 
#to the model deicision making progress


# In[ ]:




